#ifndef NETSTER_H
#define NETSTER_H
#include "chat.h"
#endif
