/*
 *  Here is the starting point for your netster part.1 includes. Add the
 *  appropriate comment header as defined in the code formatting guidelines.
 */

#ifndef P1_H
#define P1_H

/* add function prototypes */
void chat_server(char*, long, int);
void chat_client(char*, long, int);

#endif
